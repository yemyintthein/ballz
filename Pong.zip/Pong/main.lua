-- Window settings
local windowWidth = 800
local windowHeight = 600

-- Paddle settings
local paddleWidth = 10
local paddleHeight = 100
local paddleSpeed = 300

-- Left paddle (Player 1)
local paddle1 = {
    x = 50,
    y = (windowHeight - paddleHeight) / 2,
    width = paddleWidth,
    height = paddleHeight,
    speed = paddleSpeed
}

-- Right paddle (Player 2/AI)
local paddle2 = {
    x = windowWidth - 50 - paddleWidth,
    y = (windowHeight - paddleHeight) / 2,
    width = paddleWidth,
    height = paddleHeight,
    speed = paddleSpeed
}

-- Ball settings
local ball = {
    x = windowWidth / 2,
    y = windowHeight / 2,
    width = 10,
    height = 10,
    speedX = 200,
    speedY = 200
}

-- Game variables
local score1 = 0
local score2 = 0

-- Background image variable
local background

-- Love2D load function
function love.load()
    love.window.setMode(windowWidth, windowHeight)
    love.window.setTitle("Pong Game")

    -- Load background image
    background = love.graphics.newImage("background.webp")
end

-- Love2D update function
function love.update(dt)
    -- Player 1 (left paddle) control
    if love.keyboard.isDown("w") then
        paddle1.y = math.max(0, paddle1.y - paddle1.speed * dt)
    elseif love.keyboard.isDown("s") then
        paddle1.y = math.min(windowHeight - paddle1.height, paddle1.y + paddle1.speed * dt)
    end

    -- Player 2 (right paddle) control (basic AI or player)
    if love.keyboard.isDown("up") then
        paddle2.y = math.max(0, paddle2.y - paddle2.speed * dt)
    elseif love.keyboard.isDown("down") then
        paddle2.y = math.min(windowHeight - paddle2.height, paddle2.y + paddle2.speed * dt)
    end

    -- Update ball position
    ball.x = ball.x + ball.speedX * dt
    ball.y = ball.y + ball.speedY * dt

    -- Ball collision with top and bottom walls
    if ball.y <= 0 then
        ball.speedY = -ball.speedY
        ball.y = 0
    elseif ball.y + ball.height >= windowHeight then
        ball.speedY = -ball.speedY
        ball.y = windowHeight - ball.height
    end

    -- Ball collision with paddles
    if checkCollision(ball, paddle1) then
        ball.speedX = -ball.speedX
        ball.x = paddle1.x + paddle1.width
    elseif checkCollision(ball, paddle2) then
        ball.speedX = -ball.speedX
        ball.x = paddle2.x - ball.width
    end

    -- Score checking
    if ball.x <= 0 then
        score2 = score2 + 1
        resetBall()
    elseif ball.x >= windowWidth then
        score1 = score1 + 1
        resetBall()
    end
end

-- Function to check collision between ball and paddle
function checkCollision(b, p)
    return b.x < p.x + p.width and
           b.x + b.width > p.x and
           b.y < p.y + p.height and
           b.y + b.height > p.y
end

-- Function to reset the ball to the center
function resetBall()
    ball.x = windowWidth / 2
    ball.y = windowHeight / 2
    ball.speedX = -ball.speedX  -- Reverse the direction
    ball.speedY = math.random(-200, 200)  -- Randomize the vertical speed
end

-- Love2D draw function
function love.draw()
    -- Draw background image
    love.graphics.draw(background, 0, 0, 0, windowWidth / background:getWidth(), windowHeight / background:getHeight())

    -- Draw paddles
    love.graphics.rectangle("fill", paddle1.x, paddle1.y, paddle1.width, paddle1.height)
    love.graphics.rectangle("fill", paddle2.x, paddle2.y, paddle2.width, paddle2.height)

    -- Draw ball
    love.graphics.rectangle("fill", ball.x, ball.y, ball.width, ball.height)

    -- Draw scores
    love.graphics.print("Player 1: " .. score1, windowWidth / 2 - 100, 20)
    love.graphics.print("Player 2: " .. score2, windowWidth / 2 + 50, 20)
end
